import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

/**
 * Diretiva personalizada: aplica destaque (cor de fundo + borda) no elemento
 * quando o usuário interage com ele (toque/clique/tab).
 *
 * Usada assim no HTML:  <ion-item appDestaque>...</ion-item>
 */
@Directive({
  selector: '[appDestaque]',
  standalone: false
})
export class DestaqueDirective {

  private ativo = false;

  constructor(private el: ElementRef<HTMLElement>, private renderer: Renderer2) {}

  // Quando o dedo/clique encosta: pinta o fundo
  @HostListener('click')
  @HostListener('touchstart')
  aoTocar(): void {
    this.ativo = !this.ativo; // alterna: toca de novo e desmarca
    this.pintar(this.ativo);
  }

  // Ao sair com o mouse/foco, remove o destaque visual
  @HostListener('mouseleave')
  @HostListener('blur')
  aoSair(): void {
    if (this.ativo) {
      this.pintar(true);
    }
  }

  private pintar(marcado: boolean): void {
    if (marcado) {
      this.renderer.setStyle(this.el.nativeElement, 'background-color', '#fff3cd');
      this.renderer.setStyle(this.el.nativeElement, 'border-left', '6px solid #f0ad4e');
      this.renderer.setStyle(this.el.nativeElement, 'transition', 'background-color .2s ease');
    } else {
      this.renderer.removeStyle(this.el.nativeElement, 'background-color');
      this.renderer.removeStyle(this.el.nativeElement, 'border-left');
    }
  }
}
