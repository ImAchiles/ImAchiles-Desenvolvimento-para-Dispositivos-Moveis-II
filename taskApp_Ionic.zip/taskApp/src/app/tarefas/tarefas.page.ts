import { Component, OnInit } from '@angular/core';
import { Tarefa } from '../models/tarefa.model';

@Component({
  selector: 'app-tarefas',
  templateUrl: './tarefas.page.html',
  styleUrls: ['./tarefas.page.scss'],
  standalone: false
})
export class TarefasPage implements OnInit {

  // Lista de tarefas (array de objetos que seguem a interface Tarefa)
  tarefas: Tarefa[] = [
    { id: 1, titulo: 'Estudar TypeScript', concluida: false },
    { id: 2, titulo: 'Fazer mockup', concluida: true },
    { id: 3, titulo: 'Praticar Ionic', concluida: false }
  ];

  // Guarda qual item está destacado pelo toque
  idDestacado: number | null = null;

  ngOnInit(): void { }

  // Chamado no toque/clique do item: a diretiva cuida da cor,
  // aqui só registramos qual tarefa foi marcada.
  destacar(id: number): void {
    this.idDestacado = (this.idDestacado === id) ? null : id;
  }

  // Marca/desmarca como concluída
  alternarConcluida(tarefa: Tarefa): void {
    tarefa.concluida = !tarefa.concluida;
  }

  // Remove uma tarefa da lista
  remover(id: number): void {
    this.tarefas = this.tarefas.filter(t => t.id !== id);
  }
}
