// Interface que padroniza os dados de uma tarefa em todo o app.
// Usar interface evita erro de digitação (ex.: "tituo") porque o
// TypeScript avisa em tempo de compilação.
export interface Tarefa {
  id: number;
  titulo: string;
  concluida: boolean;
}
