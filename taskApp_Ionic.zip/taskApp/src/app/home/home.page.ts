import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: false
})
export class HomePage {

  totalTarefas = 3;

  constructor(private navCtrl: NavController) {}

  // Navega da Home para a tela de listagem (pela rota lazy-loading)
  abrirTarefas(): void {
    this.navCtrl.navigateForward('/tarefas');
  }
}
